file_cache_path "/root/chef-solo"
cookbook_path "/root"
