name		          'mysql'
maintainer        'Opscode, Inc.'
maintainer_email  'cookbooks@opscode.com'
license           'Apache 2.0'
description       'Installs and configures mysql for client or server'
long_description  IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version           '4.1.2'
recipe            'mysql', 'Includes the client recipe to configure a client'
recipe            'mysql::client', 'Installs packages required for mysql clients using run_action magic'
recipe            'mysql::server', 'Installs packages required for mysql servers w/o manual intervention'
recipe            'mysql::server_ec2', 'Performs EC2-specific mountpoint manipulation'

# actually tested on
supports 'redhat'
supports 'amazon'
supports 'centos'
supports 'debian'
supports 'ubuntu'

# code bits around, untested. remove?
supports 'freebsd'
supports 'mac_os_x'
supports 'scientific'
supports 'suse'
supports 'windows'

depends "openssl"
depends "build-essential"

# wat
depends 'homebrew'
depends 'windows'

