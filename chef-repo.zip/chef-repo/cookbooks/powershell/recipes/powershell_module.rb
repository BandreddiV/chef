#
# Author:: Siddheshwar More (<siddheshwar.more@clogeny.com>)
# Cookbook Name:: powershell
# Recipe:: powershell_module
#
# Copyright:: Copyright (c) 2014-2016 Chef Software, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#

# Install ps_module
# powershell_module "PsUrl" do
#   package_name "PsUrl"
#   source "https://example.com/PsUrl"
# end

# this will uninstall the ps module
# powershell_module "Uninstall PsUrl" do
#   package_name "PsUrl"
#   action :uninstall
# end
